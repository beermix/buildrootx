//===----------------------------------------------------------------------===/
//                          Kaleidoscope with MCJIT
//===----------------------------------------------------------------------===//

The files in this directory are meant to accompany a series of blog posts
that describe the process of porting the Kaleidoscope tutorial to use the MCJIT
execution engine instead of the older JIT engine.

When the blog posts are ready this file will be updated with links to the posts.

These directories contain Makefiles that allow the code to be built in a
standalone manner, independent of the larger LLVM build infrastructure.